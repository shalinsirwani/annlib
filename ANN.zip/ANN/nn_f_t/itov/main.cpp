#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

using namespace std;
using namespace cv;

vector<double> matToVector(Mat dst)
{
        //assert(dst.channels() == 1);
        vector<double> data;
        //int con = 0;
        for(int r = 0; r < dst.rows; r++) {
        for(int c = 0; c < dst.cols; c++) {
        double val = (double)dst.at<uchar>(r, c);
        //cout<<val<<" ";
        //val = 255 - val;
        if(val < 255) {
        val /= 255;
        }
        data.push_back(val);
        //con++;
        }
    }
    //cout<<dst.rows<<" X "<<dst.cols<<endl;
    return data;
}

int main()
{
    ofstream fs("training.csv");
    ifstream tin("train.csv");
    ofstream labst("label.csv");
    //ifstream fin("training.csv");
    /*string line;
  while(getline(fin , line)) {
    vector<double>  dRow;
    string          tok;
    stringstream    ss(line);

    while(getline(ss, tok, ',')) {
      //dRow.push_back(stof(tok));
        cout<<tok<<" ";
    }
    //data.push_back(dRow);
  }*/
    vector<string> label;
    string l;
    int tc=0;
    while(getline(tin , l))
    {
        stringstream st(l);
        string str;
        int con = 0 , flag = 0;
        while(getline(st , str , ','))
        {
            //cout<<str<<" "<<con<<endl;
            if(con == 1)
            {
                label.push_back(str);
                tc++;
                //cout<<tc<<"\n";
                //break;
            }
            Mat src;
            //int flag = 0;
            string app = "train-images/" + str;
            src = imread(app , IMREAD_COLOR);
            if(!src.empty())
            {
                Size size(150 , 150);
                Mat dst;
                resize(src , dst , size);
                //imshow("cj" , dst);
                //waitKey(0);
                vector<double> data;
                data = matToVector(dst);
                for(int j = 0; j < data.size(); j++) 
                {
                    fs << data.at(j);
                    if(j != (data.size() - 1)) 
                    {
                        fs << ",";
                    } 
                    else 
                    {
                        fs << endl;
                    }
                }
                data.clear();
            }
            else
            {
                //flag = 1;
                cout<<"image not find\n";
                break;
            }
            con++;
            //cout<<tc<<endl;
        }
        if(tc == 1)
            break;
    }
    cout<<label.size()<<" ";
    for(int j=0;j<label.size();j++)
    {
        labst<<label[j]<<"\n";
    }

    return 0;
}